// ItemType.java
// an enum for specifying what type an item is
// this is important when it comes to equipping

public enum ItemType {
    Weapon,
    Armor,
    Other
}

